module.exports = {
  extends: 'next/core-web-vitals',
  parserOptions: {
    project: __dirname + '/tsconfig.json'
  }
}
